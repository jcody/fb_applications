<?php // Do not delete these lines
	if ('comments.php' == basename($_SERVER['SCRIPT_FILENAME']))
		die ('Please do not load this page directly. Thanks!');

        if (!empty($post->post_password)) { // if there's a password
            if ($_COOKIE['wp-postpass_' . COOKIEHASH] != $post->post_password) {  // and it doesn't match the cookie
				?>

				<h2>This post is password protected. Enter the password to view comments.</h2>

				<?php
				return;
            }
        }

		/* This variable is for alternating comment background */
		$alt = false;
?>
<h2 class="comment-head"><?php if(comments_open()) { comments_number('No Response to ', '1 Response to ', '% Responses to ' ); the_title(); } else { echo 'COMMENTS ARE CLOSED'; } ?></h2>
<?php if ( have_comments() ) : ?>
<ol class="comment-list">
	<?php wp_list_comments('type=comment&callback=wp_threaded_comments'); ?>
</ol>
<?php else: ?>
<p style="padding-top:10px; ">Still quiet here.</p>
<?php endif; ?>
<?php if ( comments_open() ) : ?>
<div id="respond">
	<h2 class="comment-head"><?php comment_form_title( 'Leave a Response', 'Leave a Response to %s' ); ?></h2>
	<div class="cancel-comment-reply">
		<small><?php cancel_comment_reply_link(); ?></small>
	</div>
	<div class="respond-form clearfix">
		<?php if ( get_option('comment_registration') && !$user_ID ) : ?>
			You must be <a href="<?php echo wp_login_url( get_permalink() ); ?>">logged in</a> to post a comment.
		<?php else : ?>
			<form action="<?php echo get_option('siteurl'); ?>/wp-comments-post.php" method="post" id="comment-form">
			<?php if ( is_user_logged_in() ) : ?>
			<p style="text-transform:uppercase; ">Logged in as <a href="<?php echo get_option('siteurl'); ?>/wp-admin/profile.php"><?php echo $user_identity; ?></a>. <a href="<?php echo wp_logout_url(get_permalink()); ?>" title="Log out of this account">Log out &raquo;</a></p>
			<?php else : ?>
			<p><input class="author" onFocus="this.style.backgroundColor='#f5f5f5'" onBlur="this.style.backgroundColor='#fff'" type="text" name="author" id="author" value="" size="22" tabindex="1" /></p>
			<p><input class="email" onFocus="this.style.backgroundColor='#f5f5f5'" onBlur="this.style.backgroundColor='#fff'" type="text" name="email" id="email" value="" size="22" tabindex="2" /></p>
			<p><input class="url" onFocus="this.style.backgroundColor='#f5f5f5'" onBlur="this.style.backgroundColor='#fff'" type="text" name="url" id="url" value="" size="22" tabindex="3" /></p>
			<?php endif; ?>
			<p><textarea onFocus="this.style.backgroundColor='#f5f5f5'" onBlur="this.style.backgroundColor='#fff'" name="comment" id="comment" tabindex="4"></textarea></p>
			<input name="submit" type="submit" class="btn blue submit-btn" tabindex="5" value="Submit Comment" /><input type="hidden" name="comment_post_ID" value="<?php echo $id; ?>" />
			<?php comment_id_fields(); ?>
			<?php do_action('comment_form', $post->ID); ?>
			</form>
		<?php endif; ?>
	</div>
</div>
<?php endif; ?>

















