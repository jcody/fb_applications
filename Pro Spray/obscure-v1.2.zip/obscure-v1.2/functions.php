<?php

	/*	REGISTER SIDEBAR
	---------------------------
	*/
	if ( function_exists('register_sidebar') )
    register_sidebar(array(
		'name' => 'Main Sidebar',
        'before_widget' => '<div class="widget"><div class="widget-body">',
        'after_widget' => '</div><div class="widget-foot"></div></div>',
        'before_title' => '<h3>',
        'after_title' => '</h3>',
    ));

	/*	REVAMP PAGE LIST
	---------------------------
	*/
	function wp_revamp_pages() {
		$page = wp_list_pages('depth=4&title_li=&exclude=1&hide_empty=0&echo=0');  
		$page = preg_replace('/title=\"(.*?)\"/','',$page);  
		echo $page;
	}
	
	/*	REVAMP SEARCH WIDGET
	---------------------------
	*/
	
	function wp_revamp_search() {
	?>
		<div class="widget">
			<div class="widget-body">
				<h3>Search</h3>
				<form id="searchform" method="get" action="<?php bloginfo('url'); ?>"> 
					<input type="text" name="s" id="s" class="search_term" value="Type in keyword and hit Enter..." onblur="if (this.value == '') {this.value = 'Type in keyword and hit Enter...';}"  onfocus="if (this.value == 'Type in keyword and hit Enter...') {this.value = '';}" /> 
				</form>
			</div>
			<div class="widget-foot"><!-- nothing goes here --></div>
		</div>
	<?php
	}
	if ( function_exists('register_sidebar_widget') ) {
	    register_sidebar_widget("Search", "wp_revamp_search");
	}
	
	/*	REVAMP CATEGORY LIST
	---------------------------
	*/
	function wp_revamp_categories() {
		$category = wp_list_categories('depth=4&title_li=&exclude=1&hide_empty=0&echo=0');  
		$category = preg_replace('/title=\"(.*?)\"/','',$category);  
		echo $category;
	}
	
	/* Display Correct Comment Count
	/* ----------------------------------------------*/
	
	add_filter('get_comments_number', 'comment_count', 0);
	function comment_count( $count ) {
		if ( ! is_admin() ) {
			global $id;
			$comments_by_type = &separate_comments(get_comments('status=approve&post_id=' . $id));
			return count($comments_by_type['comment']);
		} 
		else {
			return $count;
		}
	}
	
	/*	POPULAR POSTS
	---------------------------
	*/
	function wp_popular_posts() {
		global $wpdb;
		
		$result = $wpdb->get_results("SELECT comment_count,ID,post_title FROM $wpdb->posts ORDER BY comment_count DESC LIMIT 0 , 5");
		foreach ($result as $post) {
			setup_postdata($post);
			$postid = $post->ID;
			$title = $post->post_title;
			$commentcount = $post->comment_count;
			if ($commentcount != 0) {
			?>
				<li><a href="<?php echo get_permalink($postid); ?>" title="Permalink to <?php echo $title; ?>"><?php echo $title; ?></a></li>
			<?php
			}
		}
	}
	
	/*	BREADCRUMB
	---------------------------
	*/
	function the_breadcrumb($is_404 = false) {
		$category = get_the_category();
		echo '<strong>You are here: </strong>';
		echo '<a href="'.get_bloginfo('url').'">Home</a> &raquo; ';
		if($is_404 == true) {
			echo 'you just found mr.404';
		}
		elseif(is_single()) {
			echo get_category_parents($category[0]->cat_ID, TRUE, ' &raquo; ');
			echo get_the_title();
		}
		elseif(is_page()) {
			$page = get_page(get_the_ID());
			
			if ($page->post_parent == 0){
				echo $page->post_name;
			}
			else {
				echo '<a href="'.get_permalink($page->post_parent).'">'.get_the_title($page->post_parent).'</a> &raquo; ';
				echo get_the_title();
			}
		}
		elseif(is_category()) {
			echo 'From the category archives &quot;';
			single_cat_title();
			echo '&quot;';
		}
		elseif(is_tag()) {
			echo 'From the tag archives &quot;';
			single_tag_title();
			echo '&quot;';
		}
		elseif(is_day()) {
			echo 'From the daily archives &quot;';
			the_time('F jS, Y');
			echo '&quot;';
		}
		elseif (is_month()) {
			echo 'From the daily archives &quot;';
			the_time('F, Y');
			echo '&quot;';
		}
		elseif (is_year()) {
			echo 'From the daily archives &quot;';
			the_time('Y');
			echo '&quot;';
		}
		elseif(is_search()) {
			echo 'You Searched &quot;';
			the_search_query();
			echo '&quot;';
		}
	}
	
	/*	POST EXCERPT
	---------------------------
	*/
	function wp_limit_post($max_char, $more_link_text = '[...]',$notagp = false, $stripteaser = 0, $more_file = '') {
		$content = get_the_content($more_link_text, $stripteaser, $more_file);
		$content = apply_filters('the_content', $content);
		$content = str_replace(']]>', ']]&gt;', $content);
		$content = strip_tags($content);
	
	   if (strlen($_GET['p']) > 0) {
	   	  if($notagp) {
		  echo substr($content,0,$max_char);
		  }
		  else {
		  echo '<p>';
		  echo substr($content,0,$max_char);
		  echo "</p>";
		  }
	   }
	   else if ((strlen($content)>$max_char) && ($espacio = strpos($content, " ", $max_char ))) {
			$content = substr($content, 0, $espacio);
			$content = $content;
			if($notagp) {
		    echo substr($content,0,$max_char);
			echo $more_link_text;
		    }
		    else {
			echo '<p>';
			echo substr($content,0,$max_char);
			echo $more_link_text;
			echo "</p>";
			}
	   }
	   else {
	      if($notagp) {
		  echo substr($content,0,$max_char);
		  }
		  else {
		  echo '<p>';
		  echo substr($content,0,$max_char);
		  echo "</p>";
		  }
	   }
	}
	
	/*	POST IMAGE GRABBER
	---------------------------
	*/
	function wp_catch_first_image($image_size = '') {  
		global $post, $posts;  
		$first_img = '';  
		ob_start();  
		ob_end_clean();  
		$output = preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', $post->post_content, $matches);  
		$first_img = $matches [1] [0];
	  	if(empty($first_img) && $image_size != ''){ //Defines a default image
			if($image_size == 's') {
				$first_img = bloginfo('template_directory')."/images/no-image-small.jpg";
			}
			else if($image_size == 'm') {
				$first_img = bloginfo('template_directory')."/images/no-image-medium.jpg";
			}
			else if($image_size == 'l') {
				$first_img = bloginfo('template_directory')."/images/no-image-large.jpg";
			}
			else {
				$first_img = '';
			}
		}  
		
		return $first_img;  
  	}
	
	/*	THREADED COMMENTS
	---------------------------
	*/
	function wp_threaded_comments($comment, $args, $depth) {
		$GLOBALS['comment'] = $comment;
	?>
		<li <?php comment_class(); ?>>
			<div class="comment">
				<div class="comment-meta-box clearfix">
					<div class="gravatar left"><?php echo get_avatar( $comment, 48 ); ?></div>
					<div class="comment-meta left">
						<span class="author"><?php if(get_comment_author_url()) : ?><a href="<?php echo get_comment_author_url(); ?>"><?php comment_author(); ?></a><?php else : ?><?php comment_author(); ?><?php endif; ?></span>
						<span class="date-link-reply"><?php printf(__('%1$s at %2$s',''), get_comment_date(), get_comment_time()); ?> | <a href="#comment-<?php comment_id(); ?>">Permalink</a> | <?php if (function_exists('comment_reply_link')) { comment_reply_link(array_merge( $args, array('add_below' => 'comment-reply', 'depth' => $depth, 'max_depth' => $args['max_depth'], 'reply_text' => 'Reply'))); } ?></span>
					</div>
				</div>
				<?php if ($comment->comment_approved == '0'): ?><p class="warning"><?php _e('Your comment is awaiting moderation.','mystique'); ?></p><?php endif; ?>
				<?php comment_text(); ?>
				<a id="comment-reply-<?php comment_ID() ?>"></a>
			</div>
	<?php
	}
	
	/*	POST IMAGE OPTION wp2.9
	---------------------------
	*/
	
	if ( function_exists('add_theme_support') ) {
		add_theme_support( 'post-thumbnails', array( 'post' ) );
		set_post_thumbnail_size( 150, 288, true );
		add_image_size('featured-post-thumbnail', 608, 608);
	}
	
	/*	SIDEBAR ADS WIDGET
	---------------------------
	*/
	function ads_widget() {
		$settings = get_option( 'ads_sidebar_widget' );  
		$code_one = $settings['codex_one'];
		$code_two = $settings['codex_two'];
		$code_three = $settings['codex_three'];
		$code_four = $settings['codex_four'];
	?>
		<div class="widget ads">
			<div class="clearfix">
				<div class="ads125box"><?php if($code_one != '') { echo $code_one; } else { echo '<a href="mailto:'.get_bloginfo('admin_email').'" title="Advertise here"><img src="'.get_bloginfo('template_directory').'/images/125x125x_blank1.jpg" border="0" alt="125x125" /></a>'; } ?></div>
				<div class="ads125box"><?php if($code_two != '') { echo $code_two; } else { echo '<a href="mailto:'.get_bloginfo('admin_email').'" title="Advertise here"><img src="'.get_bloginfo('template_directory').'/images/125x125x_blank1.jpg" border="0" alt="125x125" /></a>'; } ?></div>
				<div class="ads125box"><?php if($code_three != '') { echo $code_three; } else { echo '<a href="mailto:'.get_bloginfo('admin_email').'" title="Advertise here"><img src="'.get_bloginfo('template_directory').'/images/125x125x_blank1.jpg" border="0" alt="125x125" /></a>'; } ?></div>
				<div class="ads125box"><?php if($code_four != '') { echo $code_four; } else { echo '<a href="mailto:'.get_bloginfo('admin_email').'" title="Advertise here"><img src="'.get_bloginfo('template_directory').'/images/125x125x_blank1.jpg" border="0" alt="125x125" /></a>'; } ?></div>
				<div class="clear"></div>
			</div>
		</div>
	<?php
	}
	
	function ads_widget_admin() {
		$settings = get_option( 'ads_sidebar_widget' );
	
		if( isset( $_POST[ 'ads_sidebar_widget' ] ) ) {
			$settings[ 'codex_one' ] = stripslashes( $_POST[ 'input_codex_one' ] );
			$settings[ 'codex_two' ] = stripslashes( $_POST[ 'input_codex_two' ] );
			$settings[ 'codex_three' ] = stripslashes( $_POST[ 'input_codex_three' ] );
			$settings[ 'codex_four' ] = stripslashes( $_POST[ 'input_codex_four' ] );
			update_option( 'ads_sidebar_widget', $settings );
		}
		
		$settings = get_option( 'ads_sidebar_widget' );  
		$code_one = $settings['codex_one'];
		$code_two = $settings['codex_two'];
		$code_three = $settings['codex_three'];
		$code_four = $settings['codex_four'];
	?>
		<p>
			<label for="input_codex_one">Place Ad Code #1 Below:</label><br />
			<textarea name="input_codex_one" id="input_codex_one" cols="" rows="6" style="width:290px;"><?php echo $code_one; ?></textarea><br/>
			
			<label for="input_codex_two">Place Ad Code #2 Below:</label><br />
			<textarea name="input_codex_two" id="input_codex_two" cols="" rows="6" style="width:290px;"><?php echo $code_two; ?></textarea><br/>
			
			<label for="input_codex_three">Place Ad Code #3 Below:</label><br />
			<textarea name="input_codex_three" id="input_codex_three" cols="" rows="6" style="width:290px;"><?php echo $code_three; ?></textarea><br/>
			
			<label for="input_codex_four">Place Ad Code #4 Below:</label><br />
			<textarea name="input_codex_four" id="input_codex_four" cols="" rows="6" style="width:290px;"><?php echo $code_four; ?></textarea><br/>
		</p>
		<input type="hidden" id="ads_sidebar_widget" name="ads_sidebar_widget" value="1" />
	<?php
	}
	
	
	if ( function_exists('register_sidebar_widget') ) { register_sidebar_widget('Obscure 125x125 Ad', 'ads_widget'); }	
	if ( function_exists('register_widget_control') ) { register_widget_control( 'Obscure 125x125 Ad', 'ads_widget_admin', 300, 200 ); }
	
	/*	THEME OPTION
	---------------------------
	*/
	$themename = "Obscure";
	$pre = "obs";
	
	$options = array();
	
	$functions_path = TEMPLATEPATH . '/inc/functions/';
	
	define( OPTION_FILES, 'base.php' );
	
	function startit() {
		global $themename, $options, $pre, $functions_path;
			
		if (function_exists('add_menu_page')) {
			$basename = basename( OPTION_FILES );
		
			// Create the main Menu
			add_menu_page( $themename . ' Options', $themename . ' Options', 8, $basename, 'build_options' );
			
			// Basic Options (Default Sub tab)
			add_submenu_page( $basename, __( $themename . ' Options &raquo; General' ), __( 'Basic Options' ), 8, 'base.php', 'build_options' );
						
		}
	}
	
	function build_options() {
		global $themename, $pre, $functions_path;
				
		$page = $_GET["page"];
		
		include( $functions_path . '/options/' . $page );
				
		if ( 'save' == $_REQUEST['action'] ) {
					
			foreach ($options as $value) {
				if( isset( $_REQUEST[ $value['id'] ] ) ) { 
					update_option( $value['id'], $_REQUEST[ $value['id'] ]  ); 
				} else { 
					delete_option( $value['id'] ); 
				} 
			}
		} 
			
		include( $functions_path . '/build.php' );
	}
	
	add_action('admin_menu', 'startit');
	
?>