<?php
/**
 * @package WordPress
 * @subpackage
 */
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" <?php language_attributes(); ?>>
<head profile="http://gmpg.org/xfn/11">
	<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
	<title><?php wp_title('&laquo;', true, 'right'); ?> <?php bloginfo('name'); ?></title>
	<link rel="alternate" type="application/rss+xml" title="<?php bloginfo('name'); ?> RSS Feed" href="<?php bloginfo('rss2_url'); ?>" />
	<link rel="alternate" type="application/atom+xml" title="<?php bloginfo('name'); ?> Atom Feed" href="<?php bloginfo('atom_url'); ?>" />
	<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
	<?php if (is_singular() && get_option('thread_comments')) wp_enqueue_script('comment-reply'); ?>
	<?php wp_head(); ?>
	<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css" media="screen" />
	<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/jquery.min.js"></script>
	<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/supersubs.js"></script>
	<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/superfish.js"></script>
	<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/jquery.cycle.js"></script>
	<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/jquery.lavalamp.1.3.2-min.js"></script>
	<script type="text/javascript">
		$(document).ready(function(){
			/*## dropdown navigation ##*/
			$('ul.sf-menu').supersubs({ 
				minWidth:    12,                                // minimum width of sub-menus in em units 
				maxWidth:    27,                                // maximum width of sub-menus in em units 
				extraWidth:  1                                  // extra width can ensure lines don't sometimes turn over 
																	// due to slight rounding differences and font-family 
			}).superfish({ 
				delay:       400,                               // delay on mouseout 
				animation:   {opacity:'show',height:'show'},    // fade-in and slide-down animation 
				speed:       'fast',                            // faster animation speed 
				autoArrows:  false,                             // disable generation of arrow mark-up 
				dropShadows: false                              // disable drop shadows 
			}).children().find('li:first').css('border-top','0px').find('a').css('border-top','0px');
			
			$('.ft-items').cycle({
				fx:'fade',
				timeout:3000,
				speed:1000,
			});
			
			$('.ft-items').hover(
				function () {
					$(this).find('img').fadeTo("fast", 0.5);
					$('.ft-items').cycle('pause');
				}, 
				function () {
					$(this).find('img').fadeTo("fast", 1);
					$('.ft-items').cycle('resume');
				}
			);
		});
	</script>
</head>
<body>
<div>
</div>
<div id="base">
	<div id="header">
		<div id="pagemenu">
			<script type="text/javascript">
				$(function() {
					$('#pagemenu ul').lavaLamp({fx: 'swing', speed: 333,click: function(event, menuItem) {return true;}});
				});
			</script>
			<ul class="sf-menu">
				<li><a href="<?php bloginfo('url'); ?>">Home</a></li>
				<?php wp_revamp_pages(); ?>
				<li class="rss" style="float:right; "><a href="#">COMMENT</a></li>
				<li class="rss" style="float:right; "><a href="#">POST</a></li>
			</ul>
		</div>
		<div id="branding">
			<div class="branding-wrap container_12 clearfix">
				<div class="logo left"><a href="<?php bloginfo('url'); ?>"><img src="<?php bloginfo('template_directory'); ?>/images/logo.png" border="0" /></a></div>
				<div class="top-ad right">
					<?php if(get_option('obs_settings_ads-top') != '') : ?>
					<?php echo stripslashes(get_option('obs_settings_ads-top')); ?>
					<?php else: ?>
					<a href="mailto:<?php bloginfo('admin_email'); ?>"><img src="<?php bloginfo('template_directory'); ?>/images/ads-top.jpg" border="0" /></a>
					<?php endif; ?>
				</div>
			</div>
		</div>
		<div id="categorymenu">
			<ul class="sf-menu">
				<?php wp_revamp_categories(); ?>
			</ul>
		</div>
		<div class="shadowline"><!-- just a shadow line style. do not add anything here or else DIE! --></div>
	</div>