<?php
	// Create an array of options.
	$getcat= get_categories('hide_empty=0');
	$allcaregory = array();
	foreach ($getcat as $cat) {
		$allcaregory[$cat->cat_ID] = $cat->cat_name;
	}
	
	$options = array(
		array(
			"name" => "Featured Gallery Option",
			"type" => "section"
		),
		array(	
			"name" => "Category Name",
			"description" => "Select the category that you would like to be featured.",
			"id" => $pre."_settings_featured-catname",
			"std" => "",
			"type" => "select",
			"options" => $allcaregory,
		),
		array(
			"name" => "Ads Block Option",
			"type" => "section"
		),
		array(	
			"name" => "468x60 BLOCK",
			"description" => "Wide ads to be displayed on top.",
			"id" => $pre."_settings_ads-top",
			"std" => "",
			"type" => "textarea",
			"size" => "50",
		),
		array(
			"name" => "SUBSCRIPTION + SOCIAL PROFILE",
			"type" => "section"
		),
		array(	
			"name" => "Feedburner ID",
			"description" => "Your feedburner ID.",
			"id" => $pre."_settings_feedburner",
			"std" => "",
			"type" => "text",
			"size" => "50",
		),
		array(	
			"name" => "Twitter ID",
			"description" => "Your twitter ID.",
			"id" => $pre."_settings_twitter",
			"std" => "",
			"type" => "text",
			"size" => "50",
		),
		array(	
			"name" => "Delicious ID",
			"description" => "Your Delicious ID.",
			"id" => $pre."_settings_delicious",
			"std" => "",
			"type" => "text",
			"size" => "50",
		),
		array(	
			"name" => "StumbleUpon ID",
			"description" => "Your StumbleUpon ID.",
			"id" => $pre."_settings_stumbleupon",
			"std" => "",
			"type" => "text",
			"size" => "50",
		),
		array(	
			"name" => "Facebook ID",
			"description" => "Your Facebook ID.",
			"id" => $pre."_settings_facebook",
			"std" => "",
			"type" => "text",
			"size" => "50",
		),
		array(	
			"name" => "Digg ID",
			"description" => "Your Digg ID.",
			"id" => $pre."_settings_digg",
			"std" => "",
			"type" => "text",
			"size" => "50",
		)
	);
				
?>