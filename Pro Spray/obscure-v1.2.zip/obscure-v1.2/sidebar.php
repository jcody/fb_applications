<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Main Sidebar') ) : ?>
<?php wp_revamp_search(); ?>
<div class="widget">
	<div class="widget-body">
		<h3>Recent Posts</h3>
		<ul>
			<?php query_posts('showposts=5'); ?>
			<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
			<li><a href="<?php the_permalink(); ?>" title="Read more &quot;<?php the_title(); ?>&quot;"><?php the_title(); ?></a></li>
			<?php endwhile; endif; ?>
		</ul>
	</div>
	<div class="widget-foot"><!-- nothing goes here --></div>
</div>
<div class="widget">
	<div class="widget-body">
		<h3>Categories</h3>
		<ul>
			<?php wp_list_categories('title_li=&depth=4'); ?>
            <li><a href="http://www.wpexplorer.com" title="Top Wordpress Themes">Top Wordpress Themes</a></li>
		</ul>
	</div>
	<div class="widget-foot"><!-- nothing goes here --></div>
</div>
<?php ads_widget(); ?>
<?php endif; ?>