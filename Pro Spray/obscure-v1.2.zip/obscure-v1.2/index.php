<?php get_header(); ?>
	<div id="main" class="container_12 clearfix">
		<div id="posts" class="grid_8">
			<!-- start featured posts -->
			<div id="featured">
				<span class="ft-hangtext">FEATURED POSTS</span>
				<div class="ft-items">
					<?php $featured = new WP_Query('showposts=5&category_name='.stripslashes(get_option('obs_settings_featured-catname'))); ?>
					<?php if ($featured->have_posts()) : while ($featured->have_posts()) : $featured->the_post(); ?>
						<div class="ft-item">
							<?php if ( function_exists('has_post_thumbnail') && has_post_thumbnail() ) : ?>
								<?php $src = wp_get_attachment_image_src( get_post_thumbnail_id(get_the_ID()), 'large', false, '' ); ?>
								<img src="<?php bloginfo( 'template_directory' ); ?>/timthumb.php?src=<?php echo $src[0]; ?>&amp;w=598&amp;h=280&amp;zc=1" border="0" alt="<?php the_title(); ?>" />
							<?php else : ?>
								<?php if( get_post_meta( $post->ID, "image_value", true ) ) : ?>
									<img src="<?php bloginfo( 'template_directory' ); ?>/timthumb.php?src=<?php echo get_post_meta( $post->ID, "image_value", true ); ?>&amp;w=598&amp;h=280&amp;zc=1" border="0" alt="<?php the_title(); ?>" />
								<?php else : ?>
									<img src="<?php bloginfo( 'template_directory' ); ?>/timthumb.php?src=<?php echo wp_catch_first_image('l'); ?>&amp;w=598&amp;h=280&amp;zc=1" border="0" alt="<?php the_title(); ?>" />
								<?php endif; ?>
							<?php endif; ?>
							<div class="ft-meta">
								<h3><a href="<?php the_permalink(); ?>" title="Continue reading &quot;<?php the_title(); ?>&quot;"><?php the_title(); ?></a></h3>
								<p><?php wp_limit_post(120,'.'); ?></p>
							</div>
						</div>
					<?php endwhile; endif; ?>
				</div>
			</div>
			<!-- start default loop post -->
			<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
			<div class="post">
				<div class="post-head clearfix">
					<h1 class="post-title left"><a href="<?php the_permalink(); ?>" title="Continue reading &quot;<?php the_title(); ?>&quot;"><?php the_title(); ?></a></h1>
					<span class="post-date right"><?php the_time('F jS, Y') ?></span>
				</div>
				<div class="post-wrap clearfix">
					<div class="post-thumb left">
						<?php if ( function_exists('has_post_thumbnail') && has_post_thumbnail() ) : ?>
							<?php $src = wp_get_attachment_image_src( get_post_thumbnail_id(get_the_ID()), 'large', false, '' ); ?>
							<img src="<?php bloginfo( 'template_directory' ); ?>/timthumb.php?src=<?php echo $src[0]; ?>&amp;w=166&amp;h=166&amp;zc=1" border="0" alt="<?php the_title(); ?>" />
						<?php else : ?>
							<?php if( get_post_meta( $post->ID, "image_value", true ) ) : ?>
								<img src="<?php bloginfo( 'template_directory' ); ?>/timthumb.php?src=<?php echo get_post_meta( $post->ID, "image_value", true ); ?>&amp;w=166&amp;h=166&amp;zc=1" border="0" alt="<?php the_title(); ?>" />
							<?php else : ?>
								<img src="<?php bloginfo( 'template_directory' ); ?>/timthumb.php?src=<?php echo wp_catch_first_image('m'); ?>&amp;w=166&amp;h=166&amp;zc=1" border="0" alt="<?php the_title(); ?>" />
							<?php endif; ?>
						<?php endif; ?>
					</div>
					<div class="post-excerpt right"><?php wp_limit_post(550,'.'); ?></div>
				</div>
				<div class="post-meta clearfix">
					<ul>
						<li class="author">By <?php the_author('') ?> |</li>
						<li class="comment"><?php comments_number('No Comment','1 Comment','% Comments'); ?> |</li>
						<li class="category"><?php the_category(', ') ?></li>
					</ul>
				</div>
			</div>
			<?php endwhile; endif; ?>
			<div class="page_navi clearfix"><?php if(function_exists('wp_pagenavi')) { wp_pagenavi(); } ?></div>
		</div>
		<div id="sidebar" class="grid_4">
			<?php get_sidebar(); ?>
		</div>
	</div>
<?php get_footer(); ?>