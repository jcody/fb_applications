<?php get_header(); ?>
	<div id="main" class="container_12 clearfix">
		<div id="posts" class="grid_8">
			<!-- start default loop post -->
			<div id="breadcrumb"><?php the_breadcrumb(); ?></div>
			<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
			<div class="post">
				<div class="post-head clearfix">
					<h1 class="post-title left"><a href="<?php the_permalink(); ?>" title="Continue reading &quot;<?php the_title(); ?>&quot;"><?php the_title(); ?></a></h1>
					<span class="post-date right"><?php the_time('F jS, Y') ?></span>
				</div>
				<div class="post-meta clearfix">
					<ul>
						<li class="author">By <?php the_author('') ?> |</li>
						<li class="comment"><?php comments_number('No Comment','1 Comment','% Comments'); ?> |</li>
						<li class="category"><?php the_category(', ') ?></li>
					</ul>
				</div>
			</div>
			<?php endwhile; endif; ?>
			<div class="page_navi clearfix"><?php if(function_exists('wp_pagenavi')) { wp_pagenavi(); } ?></div>
		</div>
		<div id="sidebar" class="grid_4">
			<?php get_sidebar(); ?>
		</div>
	</div>
<?php get_footer(); ?>