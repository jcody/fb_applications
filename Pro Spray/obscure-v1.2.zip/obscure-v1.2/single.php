<?php get_header(); ?>
	<div id="main" class="container_12 clearfix">
		<div id="posts" class="grid_8">
			<!-- start default loop post -->
			<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
			<div id="breadcrumb"><?php the_breadcrumb(); ?></div>
			<div class="post">
				<div class="post-head clearfix">
					<h1 class="post-title left"><a href="<?php the_permalink(); ?>" title="Continue reading &quot;<?php the_title(); ?>&quot;"><?php the_title(); ?></a></h1>
					<span class="post-date right"><?php the_time('F jS, Y') ?></span>
				</div>
				<?php if(wp_catch_first_image() != '') : ?>
				
				<?php elseif( get_post_meta( $post->ID, "image_value", true ) || function_exists('has_post_thumbnail') && has_post_thumbnail() ) : ?>
				<div class="post-image">
					<?php if ( function_exists('has_post_thumbnail') && has_post_thumbnail() ) : ?>
						<?php $src = wp_get_attachment_image_src( get_post_thumbnail_id(get_the_ID()), 'large', false, '' ); ?>
						<img src="<?php bloginfo( 'template_directory' ); ?>/timthumb.php?src=<?php echo $src[0]; ?>&amp;w=598&amp;h=280&amp;zc=1" border="0" alt="<?php the_title(); ?>" />
					<?php else : ?>
						<?php if( get_post_meta( $post->ID, "image_value", true ) ) : ?>
							<img src="<?php bloginfo( 'template_directory' ); ?>/timthumb.php?src=<?php echo get_post_meta( $post->ID, "image_value", true ); ?>&amp;w=598&amp;h=280&amp;zc=1" border="0" alt="<?php the_title(); ?>" />
						<?php endif; ?>
					<?php endif; ?>
				</div>
				<?php endif; ?>
				<div class="post-content">
					<?php the_content(); ?>
				</div>
				<div class="post-meta clearfix">
					<ul>
						<li class="author">By <?php the_author('') ?> |</li>
						<li class="category"><?php the_category(', ') ?></li>
					</ul>
				</div>
			</div>
			<div id="comments"><?php comments_template(); ?></div>
			<?php endwhile; else: ?>
			<div id="breadcrumb"><?php the_breadcrumb(true); ?></div>
			<div class="post">
				<div class="post-head clearfix">
					<h1 class="post-title left">NOT FOUND!</h1>
					<span class="post-date right">404 error</span>
				</div>
				<div class="post-content"><p>Sorry, but you are looking for something that isn't here.</p></div>
			</div>
			<?php endif; ?>
		</div>
		<div id="sidebar" class="grid_4">
			<?php get_sidebar(); ?>
		</div>
	</div>
<?php get_footer(); ?>